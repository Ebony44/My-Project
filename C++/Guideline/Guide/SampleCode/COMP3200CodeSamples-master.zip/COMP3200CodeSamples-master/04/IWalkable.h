#pragma once

namespace samples
{
	class IWalkable
	{
	public:
		virtual void Walk() const = 0;
	};
}
