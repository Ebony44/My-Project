#pragma once

namespace samples
{
	void InterfaceExample();
}
