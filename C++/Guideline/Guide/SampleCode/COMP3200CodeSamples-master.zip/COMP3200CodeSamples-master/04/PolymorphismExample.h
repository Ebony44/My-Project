#pragma once

namespace samples
{
	void PolymorphismExample();
}
