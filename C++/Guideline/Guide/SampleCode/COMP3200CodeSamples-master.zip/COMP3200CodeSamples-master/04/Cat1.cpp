#include <iostream>
#include "Cat1.h"

namespace samples
{
	void Cat1::Walk() const
	{
		std::cout << "A cat is walking" << std::endl;
	}
}