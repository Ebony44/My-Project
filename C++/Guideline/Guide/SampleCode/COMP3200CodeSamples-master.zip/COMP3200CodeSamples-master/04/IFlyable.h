#pragma once

namespace samples
{
	class IFlyable	
	{
	public:
		virtual void Fly() const = 0;
	};
}