#pragma once

namespace samples
{
	void SpeedTestExample();
}