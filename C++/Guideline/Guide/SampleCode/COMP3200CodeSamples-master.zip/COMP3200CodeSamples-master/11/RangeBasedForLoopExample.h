#pragma once

namespace samples
{
	void RangeBasedForLoopExample();
}

