#pragma once

namespace samples
{
	void UsingUniquePointersExample();
}
