#pragma once

namespace samples 
{
	void FixedVectorExample();
}