#pragma once

namespace samples
{
	void MathExample();
}
