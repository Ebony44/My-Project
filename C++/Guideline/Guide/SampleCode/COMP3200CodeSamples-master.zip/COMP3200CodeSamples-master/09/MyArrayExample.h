#pragma once

namespace samples
{
	void MyArrayExample();
}
