#pragma once

namespace samples
{
	void CopyingVectorExample();
}