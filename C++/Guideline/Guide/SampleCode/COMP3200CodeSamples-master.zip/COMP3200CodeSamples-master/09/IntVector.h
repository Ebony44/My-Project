#pragma once

namespace samples
{
	class IntVector
	{
	public:
		IntVector();
		IntVector(int x, int y);
		
	private:
		int mX;
		int mY;
	};
}