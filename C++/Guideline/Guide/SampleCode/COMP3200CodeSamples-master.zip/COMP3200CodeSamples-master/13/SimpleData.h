#pragma once

#include <string>

namespace samples
{
	struct SimpleData
	{
	public: 
		std::string Key;
		int Value;
	};
}