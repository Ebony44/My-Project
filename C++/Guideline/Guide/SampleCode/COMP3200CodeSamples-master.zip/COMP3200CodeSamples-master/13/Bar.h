#pragma once

namespace samples
{
	class Bar
	{
	public:
		Bar() = default;
		Bar(int a, int b, int c);
		~Bar() = default;
	};
}

