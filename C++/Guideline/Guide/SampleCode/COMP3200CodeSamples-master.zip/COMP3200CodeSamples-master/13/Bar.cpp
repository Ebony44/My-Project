#include "Bar.h"

namespace samples
{
	Bar::Bar(int a, int b, int c)
	{
	}
}

