#include "Foo.h"

namespace samples
{
	Foo::Foo(float f1)
	{
	}

	Foo::Foo(float f1, float f2)
	{
	}
}
