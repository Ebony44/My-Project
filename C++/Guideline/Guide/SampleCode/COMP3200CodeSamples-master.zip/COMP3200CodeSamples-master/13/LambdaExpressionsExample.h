#pragma once

namespace samples
{
	void LambdaExpressionsExample();
}