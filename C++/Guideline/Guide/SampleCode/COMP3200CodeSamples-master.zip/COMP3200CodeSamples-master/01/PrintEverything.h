#pragma once

namespace samples
{
	void PrintEverythingExample();
}