#pragma once

namespace samples
{
	void PrintMenuExample();
}