#include "HiPope.h"
#include <iostream>

using namespace std;

namespace hi
{
	void SayHelloExample()
	{
		cout << "Hi Pope." << endl;
	}
}
