#include "HelloPope.h"
#include <iostream>

using namespace std;

namespace hello
{
	void SayHelloExample()
	{
		cout << "Hello Pope." << endl;
	}	
}
