#pragma once

namespace samples
{
	void SwapExample();
	void Swap(int& number1, int& number2);
}