#pragma once

namespace samples
{
	void ReverseInputStringExample();
}