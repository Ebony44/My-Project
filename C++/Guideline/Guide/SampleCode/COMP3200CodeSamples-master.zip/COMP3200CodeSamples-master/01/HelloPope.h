#pragma once

namespace hello
{
	void SayHelloExample();
}