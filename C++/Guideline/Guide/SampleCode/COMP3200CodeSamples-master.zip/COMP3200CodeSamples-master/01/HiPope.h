#pragma once

namespace hi
{
	void SayHelloExample();
}