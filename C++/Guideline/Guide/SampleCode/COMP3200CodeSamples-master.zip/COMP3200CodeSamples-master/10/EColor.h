#pragma once

namespace samples
{
	enum class eColor
	{
		Red,
		Green,
		Blue
	};
}