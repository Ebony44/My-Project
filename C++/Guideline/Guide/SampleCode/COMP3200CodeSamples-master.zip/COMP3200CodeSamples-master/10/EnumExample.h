#pragma once

namespace samples
{
	void EnumExample();
}

