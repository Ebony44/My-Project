#pragma once

namespace samples
{
	struct IntVector4D
	{
	public:
		int X;
		int Y;
		int Z;
		int W;
	};
}