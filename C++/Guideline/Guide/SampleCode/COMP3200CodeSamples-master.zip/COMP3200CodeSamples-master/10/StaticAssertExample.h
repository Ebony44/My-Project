#pragma once

namespace samples
{
	void StaticAssertExample();
}
