#pragma once

namespace samples
{
	void DefaultDeleteFinalOverrideExample();
}