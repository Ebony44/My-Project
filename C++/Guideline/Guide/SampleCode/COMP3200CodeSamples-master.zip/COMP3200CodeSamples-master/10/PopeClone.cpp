#include <iostream>
#include "PopeClone.h"

using namespace std;

namespace samples
{
	//PopeClone::PopeClone()
	//	: Pope("Pope")
	//{
	//}

	//void PopeClone::SayMyName() const
	//{
	//	cout << "I'm Pope's clone!!!" << "My name is also " << mName << endl;
	//}
}

