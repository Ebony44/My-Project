#pragma once

namespace samples
{
	void AutoKeywordExample();
}