#pragma once

namespace samples
{
	struct IntVector3D
	{
	public:
		int X;
		int Y;
		int Z;
	};
}