#pragma once

#include "Pope.h"

namespace samples
{
	// Compile error
	/*class PopeClone : public Pope
	{
	public:
		PopeClone();

		virtual ~PopeClone() override = default;

		virtual void SayMyName() const override;
	};*/
}