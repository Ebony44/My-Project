#pragma once

namespace samples
{
	void CacheExample();
}
