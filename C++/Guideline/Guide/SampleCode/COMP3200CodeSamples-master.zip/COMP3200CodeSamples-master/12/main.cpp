#include "SinglyLinkedListExample.h"
#include "CacheExample.h"
#include "MoveConstructorAssignmentExample.h"

using namespace samples;

int main()
{
	SinglyLinkedListExample();

	CacheExample();

	MoveConstructorAssignmentExample();

	return 0;
}