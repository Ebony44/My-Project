#pragma once

#include "MyString.h"

namespace samples
{
	void MoveConstructorAssignmentExample();

	MyString MakeMyString();
}