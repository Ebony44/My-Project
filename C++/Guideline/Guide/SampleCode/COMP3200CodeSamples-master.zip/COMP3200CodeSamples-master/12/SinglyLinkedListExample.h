#pragma once

namespace samples
{
	void SinglyLinkedListExample();
}
