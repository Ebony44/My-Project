#pragma once

namespace samples
{
	void CopyConstructorExample();
}