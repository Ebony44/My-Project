#pragma once

namespace samples
{
	void OperatorOverloadExample();
}