#pragma once

namespace samples
{
	void FunctionOverloadExample();
}