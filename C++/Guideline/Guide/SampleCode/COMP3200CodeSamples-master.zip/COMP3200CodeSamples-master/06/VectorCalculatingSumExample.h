#pragma once

#include <vector>

namespace samples
{
	int CalculateSum(const std::vector<int>& scores);

	void VectorCalculatingSumExample();
}