#pragma once

#include <vector>

namespace samples
{
	void PrintScores(const std::vector<int>& scores);

	void VectorAddingElementsExample();
}