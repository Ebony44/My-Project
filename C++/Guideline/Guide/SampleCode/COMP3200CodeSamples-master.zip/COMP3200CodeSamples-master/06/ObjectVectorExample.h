#pragma once

#include <vector>

#include "Score.h"

namespace samples
{
	void ObjectVectorExample();

	void PrintVector(const std::vector<Score>& scores);
}