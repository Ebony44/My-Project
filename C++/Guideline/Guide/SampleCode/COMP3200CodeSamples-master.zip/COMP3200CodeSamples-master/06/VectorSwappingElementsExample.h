#pragma once

namespace samples
{
	void VectorSwappingElementsExample();
}