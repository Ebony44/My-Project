#pragma once

namespace samples
{
	void StaticMemberVariableExample();
}