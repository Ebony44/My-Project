#pragma once

namespace samples
{
	class Tiger
	{
	public:
		Tiger(int age);

		void PretendIAmAZebra() const;

	private:
		int mAge;
	};
}