#pragma once

namespace samples
{
	void ValueCastingExample();
}