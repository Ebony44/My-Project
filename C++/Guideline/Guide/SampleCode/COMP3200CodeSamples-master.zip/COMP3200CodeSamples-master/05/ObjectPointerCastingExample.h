#pragma once

namespace samples
{
	void ObjectPointerCastingExample();
}