#pragma once

namespace samples
{
	void StaticMemberFunctionExample();
}