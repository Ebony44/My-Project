#pragma once

namespace samples
{
	void ObjectAddressSavingExample();
}