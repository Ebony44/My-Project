#pragma once

class Vector1
{
public:
	Vector1();
	Vector1(int x, int y);

private:
	int mX;
	int mY;
};