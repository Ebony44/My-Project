#pragma once

namespace samples
{
	void PrintRecordExample();
}
