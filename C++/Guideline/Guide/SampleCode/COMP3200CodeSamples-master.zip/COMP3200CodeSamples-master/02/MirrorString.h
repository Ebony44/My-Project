#pragma once

namespace samples
{
	void MirrorStringExample();
}
