#pragma once

namespace samples
{
	void VectorExample1();
}