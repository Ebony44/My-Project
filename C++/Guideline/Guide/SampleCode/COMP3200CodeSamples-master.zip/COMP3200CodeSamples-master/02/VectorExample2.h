#pragma once

namespace samples
{
	void VectorExample2();
}