#pragma once

namespace samples
{
	void FileSystemExample();
}
