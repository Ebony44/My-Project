#pragma once

namespace samples
{
	void Timer();

	void Resetter();

	void AutoResetTimerExample();
}
