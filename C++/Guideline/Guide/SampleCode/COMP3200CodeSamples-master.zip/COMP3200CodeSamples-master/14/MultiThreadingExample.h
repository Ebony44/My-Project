#pragma once

namespace samples
{
	void Multiply(int rhs);

	void SlowAdd(int rhs);

	void MultiThreadingExample();
}
