#pragma once

namespace samples
{
	void MapUserDefinedTypesExample1();
}