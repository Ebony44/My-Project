#pragma once

namespace samples
{
	void MapInsertingWithOperatorExample();
}