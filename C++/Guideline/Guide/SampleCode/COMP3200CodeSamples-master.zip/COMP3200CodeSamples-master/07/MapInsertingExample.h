#pragma once

namespace samples
{
	void MapInsertingExample();
}