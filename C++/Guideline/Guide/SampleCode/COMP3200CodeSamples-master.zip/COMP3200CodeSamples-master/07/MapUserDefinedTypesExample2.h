#pragma once

namespace samples
{
	void MapUserDefinedTypesExample2();
}